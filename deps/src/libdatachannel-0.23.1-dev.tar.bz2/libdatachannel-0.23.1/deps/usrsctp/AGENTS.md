# Repository Guidelines

## Project Structure & Module Organization
- `usrsctplib/`: Core SCTP stack sources (netinet headers, userspace socket glue, platform shims).
- `programs/`: Example apps (e.g., `discard_server`, `client`) that double as smoke tests.
- Build tooling: `CMakeLists.txt`, `cmake/` modules, `meson.build`, `meson_options.txt`, `Makefile.am`, `Makefile.nmake`, and `bootstrap` for autotools.
- Docs and packaging: `Manual.md`, `Manual.tex`, `LICENSE.md`, `usrsctp.pc.in`, `fuzzer/` harnesses, and helper scripts like `gen-def.py`.

## Build, Test, and Development Commands
- Autotools (Unix-like): `./bootstrap && ./configure && make` → library under `usrsctplib/`; install with `sudo make install` if needed.
- CMake (out-of-tree recommended): `cmake -S . -B build -DCMAKE_BUILD_TYPE=Release && cmake --build build`.
- Meson/Ninja: `meson setup builddir && ninja -C builddir` for a fast local build.
- Windows: `nmake -f Makefile.nmake` from the repo root.
- Smoke tests: build, then run `./programs/discard_server 11111 22222` and `./programs/client 127.0.0.1 9 0 22222 11111` to verify send/recv; use UDP encapsulation ports to avoid raw socket privileges.

## Coding Style & Naming Conventions
- C sources follow BSD-style headers and K&R braces; match existing indentation and spacing in touched files (don’t reformat wholesale).
- Public API uses the `usrsctp_` prefix; macros and constants are uppercase (`SCTP_*`), structs/types use snake_case.
- Keep lines readable (~80–100 cols), favor explicit casts, and include headers from `usrsctplib/` with angle brackets.
- Update or add comments only where they clarify non-obvious logic; keep them terse.

## Testing Guidelines
- There is no large unit-test suite; rely on example programs plus any configured Meson/CMake tests (`meson test -C builddir` or `ctest --test-dir build` when targets exist).
- For behavioral changes, add a minimal repro in `programs/` or extend existing samples to cover the new path.
- Fuzzers under `fuzzer/` should still build; run their targets in hardened environments when modifying parsing or packet handling.

## Commit & Pull Request Guidelines
- Use short, imperative subjects (“Fix INIT chunk parsing”) with focused commits; wrap body text at ~72 chars and reference issues/PRs when applicable.
- Describe behavior changes and testing performed in the PR description; link to CI runs if available.
- Keep diffs scoped to the feature/bugfix, update docs (`Manual.md`, `README.md`) when interfaces or behaviors move, and include platform notes if changes affect Windows vs Unix builds.
