# SCTP vs QUIC/HTTP 性能差异分析

## 1. 核心结论

经过对 `libdatachannel` 和 `usrsctp` 代码的分析，SCTP (Reno/BBR) 速度 (3.5MB/s) 远低于 QUIC/HTTP (10MB/s) 的主要原因如下：

1.  **usrsctp BBR 实现缺失核心机制 (Pacing)**：
    *   `usrsctp` 中的 BBR 实现是一个不完整的移植。
    *   **缺失 Pacing (发送速率控制)**：BBR 算法极其依赖 Pacing 来平滑发送流量，避免填满瓶颈队列。在 `sctp_cc_functions.c` 中，`bbr_set_pacing_rate` 和 `sctp_bbr_cwnd_update_after_output` 函数体为空或未实现真正的 Pacing 逻辑。
    *   **后果**：没有 Pacing，BBR 会退化为基于窗口的突发发送，导致在网络瓶颈处造成排队和丢包，性能大幅下降，甚至不如优化过的 Cubic/Reno。

2.  **SCTP over UDP 的协议开销与实现限制**：
    *   **用户态协议栈开销**：`usrsctp` 运行在用户态，通过 UDP 封装。相比于高度优化的 QUIC 协议栈 (如 lsquic, quiche)，`usrsctp` 在包处理、内存拷贝和定时器精度上可能存在劣势。
    *   **MTU 限制**：`libdatachannel` 默认禁用了 PMTUD (Path MTU Discovery)，并将 MTU 设置为保守值 (约 1350 字节)。QUIC 实现通常会尝试探测更大的 MTU，从而提高吞吐量。

3.  **Reno 算法的局限性**：
    *   Reno 是基于丢包的拥塞控制。在 10MB/s (80Mbps) 的速率下，即使是极低的随机丢包率 (如 0.1%) 也会导致 Reno 频繁减半拥塞窗口，从而限制吞吐量。QUIC (通常使用 Cubic 或 BBR) 对丢包更鲁棒。

## 2. 代码级证据

### 2.1 BBR 实现缺陷 (`sctp_cc_functions.c`)

在 `deps/usrsctp/usrsctplib/netinet/sctp_cc_functions.c` 中：

*   **Pacing 未实现**：
    ```c
    static void bbr_set_pacing_rate(struct sctp_nets *net, uint32_t bw, int gain)
    {
        /* SCTP doesn't have per-socket pacing rate in the same way as TCP.
           ...
           For now, we just calculate it but SCTP output might not use it unless we modify it.
           We will focus on CWND. */
    }
    ```
    代码明确注释说明 SCTP 没有像 TCP 那样的 Pacing 机制，因此 BBR 无法控制发包间隔。

*   **Output Hook 无操作**：
    ```c
    static void sctp_bbr_cwnd_update_after_output(...)
    {
        /* BBR handles pacing internally, but we can enforce burst limit if needed */
    }
    ```
    这里没有任何逻辑来限制发送，导致 BBR 可能瞬间发送大量数据包 (Burst)，造成网络拥塞。

### 2.2 Socket 配置 (`sctptransport.cpp`)

*   **接收/发送缓冲区**：
    `libdatachannel` 将 SCTP 的 `SO_RCVBUF` 和 `SO_SNDBUF` 设置为 1MB。
    ```cpp
    usrsctp_sysctl_set_sctp_recvspace(1024 * 1024);
    ```
    对于 10MB/s 的速率，如果 RTT 超过 100ms (1MB / 10MB/s = 0.1s)，1MB 的窗口将成为瓶颈。QUIC 协议通常具有自动调整窗口大小 (Auto-tuning) 的能力，可以达到更大的窗口。

*   **MTU 设置**：
    代码中禁用了 PMTUD 并且使用了较小的 MTU：
    ```cpp
    #define USE_PMTUD 0
    // ...
    size_t pmtu = config.mtu.value_or(DEFAULT_MTU) - 12 - 48 - 8 - 40;
    ```
    这增加了头部开销占比，降低了有效吞吐量。

## 3. 为什么 QUIC 更快？

*   **完整的 BBR/Cubic 实现**：QUIC 协议栈通常包含完整的、经过验证的 BBR 实现，包含精确的 Pacing 和带宽估计。
*   **UDP 优化**：QUIC 专为 UDP 设计，使用了 `sendmmsg`/`recvmmsg` 批量收发，减少系统调用开销。
*   **更先进的恢复机制**：QUIC 支持 SACK ranges (比 SCTP 更灵活)、PTO (Probe Timeout) 等机制，能更快地从丢包中恢复。

## 4. 建议

如果要提升 SCTP 性能以接近 QUIC：

1.  **尝试增大缓冲区**：在 `libdatachannel` 配置中，尝试将 `sendBufferSize` 和 `recvBufferSize` 增加到 4MB 或 8MB。
2.  **启用/优化 MTU**：如果网络环境允许，尝试启用 PMTUD 或手动设置更大的 MTU (如 1400+)。
3.  **修复 BBR 或使用 Cubic**：
    *   由于 `usrsctp` 的 BBR 缺少 Pacing，建议尝试使用 **Cubic** (如果 `usrsctp` 支持且实现较好)，Cubic 通常比 Reno 表现更好。
    *   或者，需要深入修改 `usrsctp` 源码，引入高精度定时器来实现 BBR 的 Pacing (工程量较大)。
4.  **检查底层 UDP Buffer**：确保操作系统层面的 UDP socket buffer (`sysctl` 设置 `net.core.rmem_max` / `wmem_max`) 足够大，否则包会在进入 SCTP 协议栈之前就被内核丢弃。
