# Repository Guidelines

## Project Structure & Module Organization
- Core sources live in `src/` with lower-level plumbing under `src/impl/`; public headers are in `include/rtc/`.
- Tests reside in `test/` (see `test/main.cpp` for the harness) with UWP resources under `test/uwp/`.
- Build configuration lives in the root `CMakeLists.txt` plus helper modules in `cmake/`; third-party code is tracked in `deps/`.
- Documentation and site assets sit in `docs/`, `pages/`, and `adoc/`; keep repo-friendly edits in these folders.

## Build, Test, and Development Commands
- Initialize submodules when relying on bundled deps: `git submodule update --init --recursive --depth 1`.
- Standard CMake build (OpenSSL backend, libjuice ICE): `cmake -B build -DUSE_GNUTLS=0 -DUSE_NICE=0 -DCMAKE_BUILD_TYPE=Release && cmake --build build -j4`.
- Build with alternate crypto/ICE: flip `USE_GNUTLS`, `USE_MBEDTLS`, or `USE_NICE`; prefer system libs with `-DPREFER_SYSTEM_LIB=ON` (or per-lib `USE_SYSTEM_*` flags).
- Linux make shortcut: `make USE_GNUTLS=0 USE_NICE=0` (Release by default).
- Run tests after building: `cmake --build build --target datachannel-tests && ./build/tests` (set `-DNO_TESTS=ON` to skip when not needed).

## Coding Style & Naming Conventions
- C++ follows `.clang-format` (LLVM base, tabs for indents, width 100, C++17 targets); JavaScript uses 2-space indents; repository-wide LF endings and final newlines per `.editorconfig`.
- Prefer PascalCase for classes (`PeerConnection`), camelCase for functions/methods, and snake_case for local helpers; keep filenames lowercase with underscores in `src/` and `test/`.
- Maintain small, focused translation units and keep public API changes mirrored between `include/rtc/` and `src/`.

## Testing Guidelines
- Tests exercise live WebRTC/WebSocket flows; they require network access and may depend on external STUN/TURN endpoints. Avoid flaky additions—use timeouts and cleanup via `rtc::Cleanup().wait_for(...)` when spawning peers.
- Group new cases alongside existing ones in `test/*.cpp`; mirror C and C++ API coverage when adding features that touch both surfaces.
- For build options (`NO_MEDIA`, `NO_WEBSOCKET`, backend switches), gate tests with the same preprocessor flags you toggle in the library.

## Commit & Pull Request Guidelines
- Commit messages are short and imperative; conventional prefixes like `feat:`/`fix:` seen in history are welcome. Keep the subject under ~72 chars and reference issues when applicable.
- PRs should describe the user-facing change, toggles used (`USE_GNUTLS`, `NO_MEDIA`, etc.), and test evidence (`./build/tests`, manual checks). Include screenshots or logs if behavior changes (e.g., handshake flows, WebSocket server output).
- Keep diffs minimal: avoid reformatting unrelated code; run `clang-format` on touched C++ files and respect `.editorconfig` before submitting.
