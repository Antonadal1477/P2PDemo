/**
 * Copyright (c) 2019-2021 Paul-Louis Ageneau
 *
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/.
 */

#include "channel.hpp"
#include "internals.hpp"

namespace rtc::impl {

void Channel::triggerOpen() {
	mOpenTriggered = true;
	try {
		openCallback();
	} catch (const std::exception &e) {
		PLOG_WARNING << "Uncaught exception in callback: " << e.what();
	}
	flushPendingMessages();
}

void Channel::triggerClosed() {
	try {
		closedCallback();
	} catch (const std::exception &e) {
		PLOG_WARNING << "Uncaught exception in callback: " << e.what();
	}
}

void Channel::triggerError(string error) {
	try {
		errorCallback(std::move(error));
	} catch (const std::exception &e) {
		PLOG_WARNING << "Uncaught exception in callback: " << e.what();
	}
}

void Channel::triggerAvailable(size_t count) {
	PLOG_DEBUG << "SctpTransport::enqueueRecv() 15 ";
	if (count == 1) {
		try {
			PLOG_DEBUG << "SctpTransport::enqueueRecv() 16 ";
			availableCallback();
			PLOG_DEBUG << "SctpTransport::enqueueRecv() 17 ";
		} catch (const std::exception &e) {
			PLOG_WARNING << "Uncaught exception in callback: " << e.what();
		}
	}

	flushPendingMessages();
}

void Channel::triggerBufferedAmount(size_t amount) {
	size_t previous = bufferedAmount.exchange(amount);
	size_t threshold = bufferedAmountLowThreshold.load();
	if (previous > threshold && amount <= threshold) {
		try {
			bufferedAmountLowCallback();
		} catch (const std::exception &e) {
			PLOG_WARNING << "Uncaught exception in callback: " << e.what();
		}
	}
}

void Channel::flushPendingMessages() {
	PLOG_DEBUG << "SctpTransport::enqueueRecv() 18 ";
	if (!mOpenTriggered)
		return;

	PLOG_DEBUG << "SctpTransport::enqueueRecv() 19 ";
	while (messageCallback) {
		PLOG_DEBUG << "SctpTransport::enqueueRecv() 20 ";
		auto next = receive();
		PLOG_DEBUG << "SctpTransport::enqueueRecv() 21 ";
		if (!next) {
			PLOG_DEBUG << "SctpTransport::enqueueRecv() 22 ";
			break;
		}
		PLOG_DEBUG << "SctpTransport::enqueueRecv() 23 ";

		try {
			PLOG_DEBUG << "SctpTransport::enqueueRecv() 24 ";
			messageCallback(*next);
			PLOG_DEBUG << "SctpTransport::enqueueRecv() 25 ";
		} catch (const std::exception &e) {
			PLOG_WARNING << "Uncaught exception in callback: " << e.what();
		}
	}
}

void Channel::resetOpenCallback() {
	mOpenTriggered = false;
	openCallback = nullptr;
}

void Channel::resetCallbacks() {
	mOpenTriggered = false;
	openCallback = nullptr;
	closedCallback = nullptr;
	errorCallback = nullptr;
	availableCallback = nullptr;
	bufferedAmountLowCallback = nullptr;
	messageCallback = nullptr;
}

} // namespace rtc::impl
